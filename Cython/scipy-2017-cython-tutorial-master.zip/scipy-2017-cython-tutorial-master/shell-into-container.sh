#!/bin/sh

docker exec -it cython-tutorial bash
